﻿/*
 * Created by SharpDevelop.
 * User: razvan
 * Date: 9/23/2024
 * Time: 9:07 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace controlClock
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private controlClock.clk clk1;
		private controlClock.clk clk2;
		private controlClock.clk clk3;
		private controlClock.clk clk4;
		private controlClock.clk clk5;
		private controlClock.clk clk6;
		private System.Windows.Forms.Timer timer1;
		private controlClock.clk clk7;
		private controlClock.clk clk8;
		private controlClock.clk clk9;
		private controlClock.clk clk10;
		private controlClock.clk clk11;
		private controlClock.clk clk12;
		private controlClock.clk clk13;
		private controlClock.clk clk14;
		private controlClock.clk clk15;
		private controlClock.clk clk16;
		private controlClock.clk clk17;
		private controlClock.clk clk18;
		private controlClock.clk clk19;
		private controlClock.clk clk20;
		private controlClock.clk clk21;
		private controlClock.clk clk22;
		private controlClock.clk clk23;
		private controlClock.clk clk24;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.Label label18;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.Label label22;
		private System.Windows.Forms.Label label23;
		private System.Windows.Forms.Label label24;
		private System.Windows.Forms.Label label25;
		private controlClock.clk clk25;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Label label26;
		private controlClock.clk clk26;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			this.clk1 = new controlClock.clk();
			this.clk2 = new controlClock.clk();
			this.clk3 = new controlClock.clk();
			this.clk4 = new controlClock.clk();
			this.clk5 = new controlClock.clk();
			this.clk6 = new controlClock.clk();
			this.clk12 = new controlClock.clk();
			this.clk11 = new controlClock.clk();
			this.clk10 = new controlClock.clk();
			this.clk9 = new controlClock.clk();
			this.clk8 = new controlClock.clk();
			this.clk7 = new controlClock.clk();
			this.clk18 = new controlClock.clk();
			this.clk17 = new controlClock.clk();
			this.clk16 = new controlClock.clk();
			this.clk15 = new controlClock.clk();
			this.clk14 = new controlClock.clk();
			this.clk13 = new controlClock.clk();
			this.clk24 = new controlClock.clk();
			this.clk23 = new controlClock.clk();
			this.clk22 = new controlClock.clk();
			this.clk21 = new controlClock.clk();
			this.clk20 = new controlClock.clk();
			this.clk19 = new controlClock.clk();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.label13 = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.label15 = new System.Windows.Forms.Label();
			this.label16 = new System.Windows.Forms.Label();
			this.label17 = new System.Windows.Forms.Label();
			this.label18 = new System.Windows.Forms.Label();
			this.label19 = new System.Windows.Forms.Label();
			this.label20 = new System.Windows.Forms.Label();
			this.label21 = new System.Windows.Forms.Label();
			this.label22 = new System.Windows.Forms.Label();
			this.label23 = new System.Windows.Forms.Label();
			this.label24 = new System.Windows.Forms.Label();
			this.label25 = new System.Windows.Forms.Label();
			this.clk25 = new controlClock.clk();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.label26 = new System.Windows.Forms.Label();
			this.clk26 = new controlClock.clk();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// timer1
			// 
			this.timer1.Enabled = true;
			this.timer1.Interval = 1000;
			this.timer1.Tick += new System.EventHandler(this.Timer1Tick);
			// 
			// clk1
			// 
			this.clk1.BackColor = System.Drawing.Color.DarkCyan;
			this.clk1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.clk1.Location = new System.Drawing.Point(839, 296);
			this.clk1.Name = "clk1";
			this.clk1.Size = new System.Drawing.Size(75, 61);
			this.clk1.TabIndex = 0;
			// 
			// clk2
			// 
			this.clk2.BackColor = System.Drawing.Color.DarkCyan;
			this.clk2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.clk2.Location = new System.Drawing.Point(839, 400);
			this.clk2.Name = "clk2";
			this.clk2.Size = new System.Drawing.Size(75, 61);
			this.clk2.TabIndex = 1;
			// 
			// clk3
			// 
			this.clk3.BackColor = System.Drawing.Color.DarkCyan;
			this.clk3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.clk3.Location = new System.Drawing.Point(926, 385);
			this.clk3.Name = "clk3";
			this.clk3.Size = new System.Drawing.Size(75, 61);
			this.clk3.TabIndex = 2;
			// 
			// clk4
			// 
			this.clk4.BackColor = System.Drawing.Color.DarkCyan;
			this.clk4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.clk4.Location = new System.Drawing.Point(1013, 400);
			this.clk4.Name = "clk4";
			this.clk4.Size = new System.Drawing.Size(75, 61);
			this.clk4.TabIndex = 3;
			// 
			// clk5
			// 
			this.clk5.BackColor = System.Drawing.Color.DarkCyan;
			this.clk5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.clk5.Location = new System.Drawing.Point(1100, 358);
			this.clk5.Name = "clk5";
			this.clk5.Size = new System.Drawing.Size(75, 61);
			this.clk5.TabIndex = 4;
			// 
			// clk6
			// 
			this.clk6.BackColor = System.Drawing.Color.DarkCyan;
			this.clk6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.clk6.Location = new System.Drawing.Point(1177, 462);
			this.clk6.Name = "clk6";
			this.clk6.Size = new System.Drawing.Size(75, 61);
			this.clk6.TabIndex = 5;
			// 
			// clk12
			// 
			this.clk12.BackColor = System.Drawing.Color.DarkCyan;
			this.clk12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.clk12.Location = new System.Drawing.Point(1728, 706);
			this.clk12.Name = "clk12";
			this.clk12.Size = new System.Drawing.Size(75, 61);
			this.clk12.TabIndex = 6;
			// 
			// clk11
			// 
			this.clk11.BackColor = System.Drawing.Color.DarkCyan;
			this.clk11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.clk11.Location = new System.Drawing.Point(1641, 766);
			this.clk11.Name = "clk11";
			this.clk11.Size = new System.Drawing.Size(75, 61);
			this.clk11.TabIndex = 7;
			// 
			// clk10
			// 
			this.clk10.BackColor = System.Drawing.Color.DarkCyan;
			this.clk10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.clk10.Location = new System.Drawing.Point(1566, 440);
			this.clk10.Name = "clk10";
			this.clk10.Size = new System.Drawing.Size(75, 61);
			this.clk10.TabIndex = 8;
			// 
			// clk9
			// 
			this.clk9.BackColor = System.Drawing.Color.DarkCyan;
			this.clk9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.clk9.Location = new System.Drawing.Point(1479, 463);
			this.clk9.Name = "clk9";
			this.clk9.Size = new System.Drawing.Size(75, 61);
			this.clk9.TabIndex = 9;
			// 
			// clk8
			// 
			this.clk8.BackColor = System.Drawing.Color.DarkCyan;
			this.clk8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.clk8.Location = new System.Drawing.Point(1392, 574);
			this.clk8.Name = "clk8";
			this.clk8.Size = new System.Drawing.Size(75, 61);
			this.clk8.TabIndex = 10;
			// 
			// clk7
			// 
			this.clk7.BackColor = System.Drawing.Color.DarkCyan;
			this.clk7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.clk7.Location = new System.Drawing.Point(1264, 517);
			this.clk7.Name = "clk7";
			this.clk7.Size = new System.Drawing.Size(75, 61);
			this.clk7.TabIndex = 11;
			// 
			// clk18
			// 
			this.clk18.BackColor = System.Drawing.Color.DarkCyan;
			this.clk18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.clk18.Location = new System.Drawing.Point(377, 463);
			this.clk18.Name = "clk18";
			this.clk18.Size = new System.Drawing.Size(77, 61);
			this.clk18.TabIndex = 12;
			// 
			// clk17
			// 
			this.clk17.BackColor = System.Drawing.Color.DarkCyan;
			this.clk17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.clk17.Location = new System.Drawing.Point(292, 440);
			this.clk17.Name = "clk17";
			this.clk17.Size = new System.Drawing.Size(77, 61);
			this.clk17.TabIndex = 13;
			// 
			// clk16
			// 
			this.clk16.BackColor = System.Drawing.Color.DarkCyan;
			this.clk16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.clk16.Location = new System.Drawing.Point(195, 435);
			this.clk16.Name = "clk16";
			this.clk16.Size = new System.Drawing.Size(77, 61);
			this.clk16.TabIndex = 14;
			// 
			// clk15
			// 
			this.clk15.BackColor = System.Drawing.Color.DarkCyan;
			this.clk15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.clk15.Location = new System.Drawing.Point(31, 251);
			this.clk15.Name = "clk15";
			this.clk15.Size = new System.Drawing.Size(77, 61);
			this.clk15.TabIndex = 15;
			// 
			// clk14
			// 
			this.clk14.BackColor = System.Drawing.Color.DarkCyan;
			this.clk14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.clk14.Location = new System.Drawing.Point(0, 517);
			this.clk14.Name = "clk14";
			this.clk14.Size = new System.Drawing.Size(77, 61);
			this.clk14.TabIndex = 16;
			// 
			// clk13
			// 
			this.clk13.BackColor = System.Drawing.Color.DarkCyan;
			this.clk13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.clk13.Location = new System.Drawing.Point(0, 614);
			this.clk13.Name = "clk13";
			this.clk13.Size = new System.Drawing.Size(77, 61);
			this.clk13.TabIndex = 17;
			// 
			// clk24
			// 
			this.clk24.BackColor = System.Drawing.Color.DarkCyan;
			this.clk24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.clk24.Location = new System.Drawing.Point(1825, 706);
			this.clk24.Name = "clk24";
			this.clk24.Size = new System.Drawing.Size(77, 61);
			this.clk24.TabIndex = 18;
			// 
			// clk23
			// 
			this.clk23.BackColor = System.Drawing.Color.DarkCyan;
			this.clk23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.clk23.Location = new System.Drawing.Point(774, 202);
			this.clk23.Name = "clk23";
			this.clk23.Size = new System.Drawing.Size(77, 61);
			this.clk23.TabIndex = 19;
			// 
			// clk22
			// 
			this.clk22.BackColor = System.Drawing.Color.DarkCyan;
			this.clk22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.clk22.Location = new System.Drawing.Point(696, 844);
			this.clk22.Name = "clk22";
			this.clk22.Size = new System.Drawing.Size(77, 61);
			this.clk22.TabIndex = 20;
			// 
			// clk21
			// 
			this.clk21.BackColor = System.Drawing.Color.DarkCyan;
			this.clk21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.clk21.Location = new System.Drawing.Point(616, 251);
			this.clk21.Name = "clk21";
			this.clk21.Size = new System.Drawing.Size(75, 61);
			this.clk21.TabIndex = 21;
			// 
			// clk20
			// 
			this.clk20.BackColor = System.Drawing.Color.DarkCyan;
			this.clk20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.clk20.Location = new System.Drawing.Point(534, 502);
			this.clk20.Name = "clk20";
			this.clk20.Size = new System.Drawing.Size(77, 61);
			this.clk20.TabIndex = 22;
			// 
			// clk19
			// 
			this.clk19.BackColor = System.Drawing.Color.DarkCyan;
			this.clk19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.clk19.Location = new System.Drawing.Point(458, 411);
			this.clk19.Name = "clk19";
			this.clk19.Size = new System.Drawing.Size(75, 61);
			this.clk19.TabIndex = 23;
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.White;
			this.label1.Location = new System.Drawing.Point(837, 360);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(77, 23);
			this.label1.TabIndex = 24;
			this.label1.Text = "GMT0";
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.ForeColor = System.Drawing.Color.White;
			this.label2.Location = new System.Drawing.Point(839, 464);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(77, 23);
			this.label2.TabIndex = 25;
			this.label2.Text = "London";
			// 
			// label3
			// 
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.ForeColor = System.Drawing.Color.White;
			this.label3.Location = new System.Drawing.Point(926, 449);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(77, 23);
			this.label3.TabIndex = 26;
			this.label3.Text = "Berlin";
			// 
			// label4
			// 
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.ForeColor = System.Drawing.Color.White;
			this.label4.Location = new System.Drawing.Point(1013, 464);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(77, 23);
			this.label4.TabIndex = 27;
			this.label4.Text = "Bucuresti";
			// 
			// label5
			// 
			this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label5.ForeColor = System.Drawing.Color.White;
			this.label5.Location = new System.Drawing.Point(1100, 422);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(77, 23);
			this.label5.TabIndex = 28;
			this.label5.Text = "Moscow";
			// 
			// label6
			// 
			this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label6.ForeColor = System.Drawing.Color.White;
			this.label6.Location = new System.Drawing.Point(1175, 526);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(77, 23);
			this.label6.TabIndex = 29;
			this.label6.Text = "Islamabad";
			// 
			// label7
			// 
			this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label7.ForeColor = System.Drawing.Color.White;
			this.label7.Location = new System.Drawing.Point(1264, 581);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(77, 23);
			this.label7.TabIndex = 30;
			this.label7.Text = "New Delhi";
			// 
			// label8
			// 
			this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label8.ForeColor = System.Drawing.Color.White;
			this.label8.Location = new System.Drawing.Point(1390, 638);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(77, 23);
			this.label8.TabIndex = 31;
			this.label8.Text = "Singapore";
			// 
			// label9
			// 
			this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label9.ForeColor = System.Drawing.Color.White;
			this.label9.Location = new System.Drawing.Point(1479, 527);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(77, 23);
			this.label9.TabIndex = 32;
			this.label9.Text = "Beijng";
			// 
			// label10
			// 
			this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label10.ForeColor = System.Drawing.Color.White;
			this.label10.Location = new System.Drawing.Point(1566, 504);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(77, 23);
			this.label10.TabIndex = 33;
			this.label10.Text = "Tokyo";
			// 
			// label11
			// 
			this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label11.ForeColor = System.Drawing.Color.White;
			this.label11.Location = new System.Drawing.Point(1639, 830);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(77, 23);
			this.label11.TabIndex = 34;
			this.label11.Text = "Melbourne";
			// 
			// label12
			// 
			this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label12.ForeColor = System.Drawing.Color.White;
			this.label12.Location = new System.Drawing.Point(1726, 770);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(77, 23);
			this.label12.TabIndex = 35;
			this.label12.Text = "Fiji";
			// 
			// label13
			// 
			this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label13.ForeColor = System.Drawing.Color.White;
			this.label13.Location = new System.Drawing.Point(774, 266);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(77, 23);
			this.label13.TabIndex = 47;
			this.label13.Text = "Rejkiavik";
			// 
			// label14
			// 
			this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label14.ForeColor = System.Drawing.Color.White;
			this.label14.Location = new System.Drawing.Point(696, 908);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(77, 41);
			this.label14.TabIndex = 46;
			this.label14.Text = "South Atlantic";
			// 
			// label15
			// 
			this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label15.ForeColor = System.Drawing.Color.White;
			this.label15.Location = new System.Drawing.Point(616, 315);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(86, 23);
			this.label15.TabIndex = 45;
			this.label15.Text = "Groenlanda";
			// 
			// label16
			// 
			this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label16.ForeColor = System.Drawing.Color.White;
			this.label16.Location = new System.Drawing.Point(536, 566);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(88, 23);
			this.label16.TabIndex = 44;
			this.label16.Text = "Caraibe";
			// 
			// label17
			// 
			this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label17.ForeColor = System.Drawing.Color.White;
			this.label17.Location = new System.Drawing.Point(456, 475);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(77, 23);
			this.label17.TabIndex = 43;
			this.label17.Text = "New York";
			// 
			// label18
			// 
			this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label18.ForeColor = System.Drawing.Color.White;
			this.label18.Location = new System.Drawing.Point(379, 527);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(77, 23);
			this.label18.TabIndex = 42;
			this.label18.Text = "Huston";
			// 
			// label19
			// 
			this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label19.ForeColor = System.Drawing.Color.White;
			this.label19.Location = new System.Drawing.Point(292, 504);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(77, 23);
			this.label19.TabIndex = 41;
			this.label19.Text = "Las Vegas";
			// 
			// label20
			// 
			this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label20.ForeColor = System.Drawing.Color.White;
			this.label20.Location = new System.Drawing.Point(195, 499);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(77, 50);
			this.label20.TabIndex = 40;
			this.label20.Text = "Los Angeles";
			// 
			// label21
			// 
			this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label21.ForeColor = System.Drawing.Color.White;
			this.label21.Location = new System.Drawing.Point(33, 315);
			this.label21.Name = "label21";
			this.label21.Size = new System.Drawing.Size(77, 23);
			this.label21.TabIndex = 39;
			this.label21.Text = "Alaska";
			// 
			// label22
			// 
			this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label22.ForeColor = System.Drawing.Color.White;
			this.label22.Location = new System.Drawing.Point(2, 581);
			this.label22.Name = "label22";
			this.label22.Size = new System.Drawing.Size(77, 23);
			this.label22.TabIndex = 38;
			this.label22.Text = "Hawaii";
			// 
			// label23
			// 
			this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label23.ForeColor = System.Drawing.Color.White;
			this.label23.Location = new System.Drawing.Point(2, 678);
			this.label23.Name = "label23";
			this.label23.Size = new System.Drawing.Size(77, 23);
			this.label23.TabIndex = 37;
			this.label23.Text = "Micronesia";
			// 
			// label24
			// 
			this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label24.ForeColor = System.Drawing.Color.White;
			this.label24.Location = new System.Drawing.Point(1825, 770);
			this.label24.Name = "label24";
			this.label24.Size = new System.Drawing.Size(77, 23);
			this.label24.TabIndex = 36;
			this.label24.Text = "Niue";
			// 
			// label25
			// 
			this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label25.ForeColor = System.Drawing.Color.White;
			this.label25.Location = new System.Drawing.Point(1728, 360);
			this.label25.Name = "label25";
			this.label25.Size = new System.Drawing.Size(77, 23);
			this.label25.TabIndex = 48;
			this.label25.Text = "Kamceatka";
			// 
			// clk25
			// 
			this.clk25.BackColor = System.Drawing.Color.DarkCyan;
			this.clk25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.clk25.Location = new System.Drawing.Point(1728, 296);
			this.clk25.Name = "clk25";
			this.clk25.Size = new System.Drawing.Size(75, 61);
			this.clk25.TabIndex = 49;
			// 
			// pictureBox1
			// 
			this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
			this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pictureBox1.Location = new System.Drawing.Point(0, 0);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(1920, 1080);
			this.pictureBox1.TabIndex = 50;
			this.pictureBox1.TabStop = false;
			this.pictureBox1.Click += new System.EventHandler(this.PictureBox1Click);
			// 
			// label26
			// 
			this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label26.ForeColor = System.Drawing.Color.White;
			this.label26.Location = new System.Drawing.Point(1766, 659);
			this.label26.Name = "label26";
			this.label26.Size = new System.Drawing.Size(77, 23);
			this.label26.TabIndex = 52;
			this.label26.Text = "Kiribati";
			// 
			// clk26
			// 
			this.clk26.BackColor = System.Drawing.Color.DarkCyan;
			this.clk26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.clk26.Location = new System.Drawing.Point(1766, 595);
			this.clk26.Name = "clk26";
			this.clk26.Size = new System.Drawing.Size(77, 61);
			this.clk26.TabIndex = 51;
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.DarkCyan;
			this.ClientSize = new System.Drawing.Size(1904, 1041);
			this.Controls.Add(this.label26);
			this.Controls.Add(this.clk26);
			this.Controls.Add(this.clk25);
			this.Controls.Add(this.label25);
			this.Controls.Add(this.label13);
			this.Controls.Add(this.label14);
			this.Controls.Add(this.label15);
			this.Controls.Add(this.label16);
			this.Controls.Add(this.label17);
			this.Controls.Add(this.label18);
			this.Controls.Add(this.label19);
			this.Controls.Add(this.label20);
			this.Controls.Add(this.label21);
			this.Controls.Add(this.label22);
			this.Controls.Add(this.label23);
			this.Controls.Add(this.label24);
			this.Controls.Add(this.label12);
			this.Controls.Add(this.label11);
			this.Controls.Add(this.label10);
			this.Controls.Add(this.label9);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.clk19);
			this.Controls.Add(this.clk20);
			this.Controls.Add(this.clk21);
			this.Controls.Add(this.clk22);
			this.Controls.Add(this.clk23);
			this.Controls.Add(this.clk24);
			this.Controls.Add(this.clk13);
			this.Controls.Add(this.clk14);
			this.Controls.Add(this.clk15);
			this.Controls.Add(this.clk16);
			this.Controls.Add(this.clk17);
			this.Controls.Add(this.clk18);
			this.Controls.Add(this.clk7);
			this.Controls.Add(this.clk8);
			this.Controls.Add(this.clk9);
			this.Controls.Add(this.clk10);
			this.Controls.Add(this.clk11);
			this.Controls.Add(this.clk12);
			this.Controls.Add(this.clk6);
			this.Controls.Add(this.clk5);
			this.Controls.Add(this.clk4);
			this.Controls.Add(this.clk3);
			this.Controls.Add(this.clk2);
			this.Controls.Add(this.clk1);
			this.Controls.Add(this.pictureBox1);
			this.Name = "MainForm";
			this.Text = "controlClock";
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.Load += new System.EventHandler(this.MainFormLoad);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);

		}
	}
}
